<?php
  require_once("config.php");
?>
<?php 
 include("include/header.php");
 include("include/nav.php");
 ?>
<?php 
 include("include/sidebar.php");
 ?>
 <div>
    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
       <div class="card">

      
        <?php
       include("placholder.php");
        ?>
       
      </div>
      <!-- /.card -->

    </section>
  </div>
  <!-- /.content-wrapper -->


  <?php 
 include("include/footer.php");
 ?>